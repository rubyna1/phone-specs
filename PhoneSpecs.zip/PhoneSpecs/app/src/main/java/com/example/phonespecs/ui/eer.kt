package com.example.phonespecs.ui

class eer {
}