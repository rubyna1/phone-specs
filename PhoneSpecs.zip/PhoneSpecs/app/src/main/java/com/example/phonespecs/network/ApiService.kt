package com.example.phonespecs.network

interface ApiService {

}