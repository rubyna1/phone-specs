package com.example.phonespecs.di.modules

class AppModule {
}