package com.example.phonespecs.di.modules

import dagger.Module

@Module
abstract class FragmentBindingModule